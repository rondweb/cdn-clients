<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressOrderItem
{
}