<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressProductVideo
{
}