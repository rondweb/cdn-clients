<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressOrder
{
}