<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressAttribute
{
}