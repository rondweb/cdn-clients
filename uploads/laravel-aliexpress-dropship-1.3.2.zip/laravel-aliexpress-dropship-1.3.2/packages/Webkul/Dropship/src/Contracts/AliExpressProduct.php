<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressProduct
{
}