<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressProductImage
{
}