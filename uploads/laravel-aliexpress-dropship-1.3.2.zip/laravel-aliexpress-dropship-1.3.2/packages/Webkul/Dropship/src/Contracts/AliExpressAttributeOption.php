<?php

namespace Webkul\Dropship\Contracts;

interface AliExpressAttributeOption
{
}