<?php

/**
 * Admin routes.
 */
require 'admin-routes.php';

/**
 * Admin routes.
 */
require 'routes.php';