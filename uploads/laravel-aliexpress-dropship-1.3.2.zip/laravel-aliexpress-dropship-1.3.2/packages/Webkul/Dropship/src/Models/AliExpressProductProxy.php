<?php

namespace Webkul\Dropship\Models;

use Konekt\Concord\Proxies\ModelProxy;

class AliExpressProductProxy extends ModelProxy
{
}