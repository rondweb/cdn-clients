<?php

namespace Webkul\Dropship\Models;

use Konekt\Concord\Proxies\ModelProxy;

class AliExpressOrderProxy extends ModelProxy
{
}