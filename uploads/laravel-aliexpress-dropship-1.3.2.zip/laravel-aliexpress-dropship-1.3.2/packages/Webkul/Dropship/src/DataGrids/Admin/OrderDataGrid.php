<?php

namespace Webkul\Dropship\DataGrids\Admin;

use Illuminate\Support\Facades\DB;
use Webkul\Ui\DataGrid\DataGrid;

class OrderDataGrid extends DataGrid
{
    /**
     *
     * @var integer
     */
    public $index = 'order_id';

    protected $sortOrder = 'desc'; //asc or desc

    public function prepareQueryBuilder()
    {
        $queryBuilder = DB::table('dropship_ali_express_orders')
                ->leftJoin('orders', 'dropship_ali_express_orders.order_id', '=', 'orders.id')
                ->leftJoin('dropship_ali_express_order_items as aliexpress_order_items', function($leftJoin) {
                    $leftJoin->on('aliexpress_order_items.ali_express_order_id', '=', 'orders.id')
                    ->where('aliexpress_order_items.parent_id', null);
                })
                ->leftjoin('order_items', 'aliexpress_order_items.order_item_id', '=', 'order_items.id')
                ->select('orders.id', 'dropship_ali_express_orders.order_id', 'dropship_ali_express_orders.ali_express_add_cart_url', 'order_items.base_total', 'dropship_ali_express_orders.created_at', 'orders.status', 'orders.base_grand_total', 'dropship_ali_express_orders.is_placed')
                ->addSelect(DB::raw('CONCAT(orders.customer_first_name, " ", orders.customer_last_name) as customer_name, orders.customer_email'))
                ->groupBy('orders.id');

        $this->addFilter('customer_name', DB::raw('CONCAT(orders.customer_first_name, " ", orders.customer_last_name)'));
        $this->addFilter('created_at', 'dropship_ali_express_orders.created_at');
        $this->addFilter('id', 'orders.id');

        $this->setQueryBuilder($queryBuilder);
    }

    public function addColumns()
    {
        $this->addColumn([
            'index'      => 'id',
            'label'      => trans('dropship::app.admin.orders.order-id'),
            'type'       => 'number',
            'searchable' => true,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'base_grand_total',
            'label'      => trans('dropship::app.admin.orders.grand-total'),
            'type'       => 'price',
            'searchable' => false,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'customer_email',
            'label'      => trans('dropship::app.admin.orders.email'),
            'type'       => 'string',
            'searchable' => true,
            'sortable'   => false,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'customer_name',
            'label'      => trans('dropship::app.admin.orders.billed-to'),
            'type'       => 'string',
            'searchable' => true,
            'sortable'   => false,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'status',
            'label'      => trans('dropship::app.admin.orders.status'),
            'type'       => 'string',
            'sortable'   => false,
            'searchable' => false,
            'filterable' => true,
            'closure'    => true,
            'wrapper'    => function ($row) {
                if ($row->status == 'processing')
                    return '<span class="badge badge-md badge-success">' . trans('dropship::app.admin.orders.processing') . '</span>';
                else if ($row->status == 'completed')
                    return '<span class="badge badge-md badge-success">' . trans('dropship::app.admin.orders.completed') . '</span>';
                else if ($row->status == 'canceled')
                    return '<span class="badge badge-md badge-danger">' . trans('dropship::app.admin.orders.canceled') . '</span>';
                else if ($row->status == 'closed')
                    return '<span class="badge badge-md badge-info">' . trans('dropship::app.admin.orders.closed') . '</span>';
                else if ($row->status == 'pending')
                    return '<span class="badge badge-md badge-warning">' . trans('dropship::app.admin.orders.pending') . '</span>';
                else if ($row->status == 'pending_payment')
                    return '<span class="badge badge-md badge-warning">' . trans('dropship::app.admin.orders.pending-payment') . '</span>';
                else if ($row->status == 'fraud')
                    return '<span class="badge badge-md badge-danger">' . trans('dropship::app.admin.orders.fraud') . '</span>';
            }
        ]);

        $this->addColumn([
            'index'      => 'is_placed',
            'label'      => trans('dropship::app.admin.orders.place-order'),
            'type'       => 'string',
            'sortable'   => false,
            'searchable' => false,
            'filterable' => false,
            'closure'    => true,
            'wrapper'    => function ($row) {
                if ($row->is_placed)
                    return trans('dropship::app.admin.orders.already-placed');

                return '<a href="https://' . $row->ali_express_add_cart_url . '" target="_blank">' . trans('dropship::app.admin.orders.checkout-on-aliexpress') . '</a>';
            }
        ]);

        $this->addColumn([
            'index'      => 'created_at',
            'label'      => trans('dropship::app.admin.orders.order-date'),
            'type'       => 'datetime',
            'sortable'   => true,
            'searchable' => false,
            'filterable' => true,
        ]);
    }

    public function prepareActions()
    {
        $this->addAction([
            'title'  => trans('admin::app.datagrid.view'),
            'type'   => 'View',
            'method' => 'GET', // use GET request only for redirect purposes
            'route'  => 'admin.sales.orders.view',
            'icon'   => 'icon eye-icon',
        ]);
    }
}